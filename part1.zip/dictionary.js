"use strict";

const dictionaries = {};
const loading = {};
const dictPopup = document.getElementById("dictPopup");
const dictResult = document.getElementById("dictResult");

function cleanWord(value) {
    if (!value) return "";
    const text = String(value).trim();
    if (/\s/.test(text)) return "";
    return text.replace(/^[^a-zA-Z'-]+/, "").replace(/[^a-zA-Z'-]+$/, "").toLowerCase();
}

async function loadDictionary(letter) {
    letter = letter.toLowerCase();
    if (dictionaries[letter]) return dictionaries[letter];
    if (loading[letter]) return loading[letter];

    loading[letter] = (async () => {
        for (const name of [`dictionary-${letter}.json`, `dictionary-${letter.toUpperCase()}.json`]) {
            try {
                const response = await fetch(name, { cache: "no-cache" });
                if (!response.ok) continue;
                const text = await response.text();
                const data = JSON.parse(text);
                dictionaries[letter] = data;
                return data;
            } catch (error) {
                console.warn(name, error);
            }
        }
        return null;
    })();

    try { return await loading[letter]; }
    finally { delete loading[letter]; }
}

async function lookupWord(value) {
    const word = cleanWord(value);
    if (!word) return;

    showMessage(word, "Looking up word...");
    const dictionary = await loadDictionary(word[0]);
    if (!dictionary) return showMessage(word, "Dictionary could not be loaded.");

    let entry = dictionary[word];
    if (!entry) {
        const key = Object.keys(dictionary).find(k => k.toLowerCase() === word);
        if (key) entry = dictionary[key];
    }
    if (!entry) return showMessage(word, "Word not found.");
    showDefinition(word, entry);
}

function showMessage(word, message) {
    dictResult.innerHTML = "";
    const title = document.createElement("div");
    title.textContent = word;
    title.style.cssText = "font-size:20px;font-weight:bold;color:#fff;margin:10px 0 8px";
    const status = document.createElement("div");
    status.textContent = message;
    status.style.color = "#aaa";
    dictResult.append(title, status);
}

function showDefinition(word, entry) {
    dictResult.innerHTML = "";

    const title = document.createElement("div");
    title.textContent = word;
    title.style.cssText = "font-size:21px;font-weight:bold;color:#fff;margin:10px 0 8px";
    dictResult.appendChild(title);

    if (entry.partOfSpeech) {
        const speech = document.createElement("div");
        speech.textContent = Array.isArray(entry.partOfSpeech) ? entry.partOfSpeech.join(", ") : String(entry.partOfSpeech);
        speech.style.cssText = "color:#69a9ff;font-style:italic;font-weight:bold;margin-bottom:10px";
        dictResult.appendChild(speech);
    }

    const definitions = Array.isArray(entry.definition)
        ? entry.definition
        : String(entry.definition || "No definition available.").split(";").map(x => x.trim()).filter(Boolean);

    definitions.forEach((text, index) => {
        const item = document.createElement("div");
        item.textContent = definitions.length > 1 ? `${index + 1}. ${text}` : text;
        item.style.marginBottom = "8px";
        dictResult.appendChild(item);
    });

    if (entry.example) {
        const example = document.createElement("div");
        example.style.cssText = "border-top:1px solid #555;padding-top:10px;color:#bdbdbd;font-style:italic";
        example.textContent = "Example: " + (Array.isArray(entry.example) ? entry.example.join(" ") : String(entry.example));
        dictResult.appendChild(example);
    }
}

document.addEventListener("mousedown", function (event) {
    if (dictPopup && !dictPopup.contains(event.target)) dictResult.innerHTML = "";
});
