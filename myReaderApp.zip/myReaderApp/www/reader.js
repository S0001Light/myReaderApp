let book;
let rendition;
let currentLocation = null;

/* Load EPUB using FileReader (correct method) */
document.getElementById("fileInput").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = function (e) {
        const bookData = e.target.result;

        book = ePub(bookData);
        rendition = book.renderTo("viewer", { width: "100%", height: "100%" });
        rendition.display();

        setupReaderEvents();
    };

    reader.readAsArrayBuffer(file);
});

/* All reader events moved into one function */
function setupReaderEvents() {

    /* Page Turn Buttons */
    document.getElementById("prevBtn").onclick = () => rendition.prev();
    document.getElementById("nextBtn").onclick = () => rendition.next();

    /* Save reading position */
    rendition.on("relocated", (location) => {
        currentLocation = location.start.cfi;
        localStorage.setItem("lastLocation", currentLocation);
    });

    /* Restore position */
    book.ready.then(() => {
        const saved = localStorage.getItem("lastLocation");
        if (saved) rendition.display(saved);
    });

    /* Inside EPUB iframe */
    rendition.on("displayed", () => {
        const iframe = document.querySelector("#viewer iframe");
        if (!iframe) return;

        const doc = iframe.contentDocument;

        /* Highlight selection */
        doc.addEventListener("mouseup", () => {
            const word = doc.getSelection().toString().trim();
            if (word) lookupWord(word);
        });

        /* Hover word lookup */
        doc.addEventListener("mouseover", (e) => {
            const sel = e.target.innerText;
            if (sel && sel.split(" ").length === 1) {
                lookupWord(sel);
            }
        });

    });
}

/* Brightness + Contrast (Global) */
document.getElementById("brightness").oninput = updateFilters;
document.getElementById("contrast").oninput = updateFilters;

function updateFilters() {
    const b2 = document.getElementById("brightness").value;
    const c2 = document.getElementById("contrast").value;

    const filterString = `brightness(${b2}%) contrast(${c2}%)`;

    const app = document.getElementById("appWrapper");
    app.style.filter = filterString;
    app.style.WebkitFilter = filterString;
}

/* Highlight Word */
function highlightWord(word) {
    const iframe = document.querySelector("#viewer iframe");
    const doc = iframe.contentDocument;

    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);

    while (walker.nextNode()) {
        const node = walker.currentNode;
        const val = node.nodeValue;

        const idx = val.toLowerCase().indexOf(word.toLowerCase());
        if (idx !== -1) {
            const span = doc.createElement("span");
            span.style.background = "yellow";
            span.textContent = val.substring(idx, idx + word.length);

            const before = doc.createTextNode(val.substring(0, idx));
            const after = doc.createTextNode(val.substring(idx + word.length));

            const parent = node.parentNode;
            parent.replaceChild(after, node);
            parent.insertBefore(span, after);
            parent.insertBefore(before, span);
        }
    }
}
