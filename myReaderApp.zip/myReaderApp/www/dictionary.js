let dictionary = {};

async function lookupWord(word) {
    word = word.toLowerCase();

    if (dictionary[word]) {
        showDefinition(word, dictionary[word]);
        return;
    }

    try {
        const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
        const data = await res.json();

        const meaning = data[0]?.meanings[0]?.definitions[0]?.definition;

        if (meaning) {
            dictionary[word] = meaning;
            showDefinition(word, meaning);
        }
    } catch (err) {
        console.log("Definition not found");
    }
}

function showDefinition(word, meaning) {
    const popup = document.getElementById("popup");
    popup.innerHTML = `<strong>${word}</strong><br>${meaning}`;
    popup.style.display = "block";
}
