"use strict";

let book = null;
let rendition = null;

const fileInput = document.getElementById("fileInput");
const viewer = document.getElementById("viewer");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const brightness = document.getElementById("brightness");
const contrast = document.getElementById("contrast");
const readingArea = document.getElementById("backgroundOfText");

fileInput.addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.name.toLowerCase().endsWith(".txt")) return loadTXT(file);
    if (file.name.toLowerCase().endsWith(".epub")) loadEPUB(file);
});

function loadEPUB(file) {
    viewer.innerHTML = "";
    const reader = new FileReader();
    reader.onload = async function (event) {
        book = ePub(event.target.result);
        rendition = book.renderTo("viewer", { width:"100%", height:"100%", flow:"paginated", spread:"none" });

        rendition.on("displayed", function () {
            rendition.getContents().forEach(function (contents) {
                const doc = contents.document;
                if (!doc || doc.__lookupInstalled) return;
                doc.__lookupInstalled = true;
                doc.addEventListener("mouseup", function () {
                    const selection = doc.getSelection();
                    if (!selection) return;
                    const word = cleanWord(selection.toString());
                    if (word) lookupWord(word);
                });
            });
        });

        rendition.on("selected", function (cfiRange, contents) {
            const selection = contents.document.getSelection();
            if (!selection) return;
            const word = cleanWord(selection.toString());
            if (word) lookupWord(word);
        });

        await rendition.display();
    };
    reader.readAsArrayBuffer(file);
}

prevBtn.addEventListener("click", async () => { if (rendition) await rendition.prev(); });
nextBtn.addEventListener("click", async () => { if (rendition) await rendition.next(); });

brightness.addEventListener("input", updateFilters);
contrast.addEventListener("input", updateFilters);
function updateFilters() {
    readingArea.style.filter = `brightness(${brightness.value}%) contrast(${contrast.value}%)`;
}
updateFilters();

function loadTXT(file) {
    viewer.innerHTML = "";
    const reader = new FileReader();
    reader.onload = function (event) {
        const pre = document.createElement("pre");
        pre.style.cssText = "white-space:pre-wrap;padding:20px;margin:0";
        pre.textContent = event.target.result;
        viewer.appendChild(pre);
        viewer.onmouseup = function () {
            const selection = window.getSelection();
            if (!selection) return;
            const word = cleanWord(selection.toString());
            if (word) lookupWord(word);
        };
    };
    reader.readAsText(file);
}
